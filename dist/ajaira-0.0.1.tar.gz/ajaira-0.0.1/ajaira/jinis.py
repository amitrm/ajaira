def tell_me_about_it():
    
    message = """
    Thanks for installing this ajaira package.
    Eat Dead!
    """

    print(message)