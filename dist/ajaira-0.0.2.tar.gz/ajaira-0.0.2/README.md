This package has been developed as a test and it does nothing. 
Thanks for installing.